import os
import json
import boto3
from PIL import Image

s3 = boto3.client('s3')

def lambda_handler(event, context):
    for record in event['Records']:
        bucket = record['s3']['bucket']['name']
        key = record['s3']['object']['key']

        # Download the image
        download_path = '/tmp/{}{}'.format(os.path.basename(key), 'downloaded')
        s3.download_file(bucket, key, download_path)

        # Process the image (example: resize)
        processed_path = '/tmp/{}{}'.format(os.path.basename(key), 'processed')
        with Image.open(download_path) as image:
            # Resize the image (you can add your custom photo editing logic here)
            resized_image = image.resize((800, 600))
            resized_image.save(processed_path)

        # Upload the processed image back to S3
        processed_key = 'processed/{}'.format(os.path.basename(key))
        s3.upload_file(processed_path, bucket, processed_key)

    return {
        'statusCode': 200,
        'body': json.dumps('Photo processing completed successfully!')
    }
